# 🚀 Deployment Guide — GitHub Actions

This guide deploys your Disinformation Monitor to GitHub Actions,
so it runs automatically every morning for free — no server needed.

---

## What you need

- A free GitHub account → https://github.com/signup
- A Gmail account with an App Password (see Step 3)

---

## Step 1 — Create a GitHub repository

1. Go to https://github.com and log in
2. Click the **"+"** button (top right) → **"New repository"**
3. Name it: `disinformation-monitor`
4. Set it to **Private** (keeps your config safe)
5. Click **"Create repository"**

---

## Step 2 — Upload the files

On the new repository page:

1. Click **"uploading an existing file"** (link in the middle of the page)
2. Drag and drop ALL the files from this zip:
   ```
   monitor.py
   config.py
   requirements.txt
   .github/
       workflows/
           daily-digest.yml
   ```
   ⚠️ Make sure the `.github/workflows/` folder structure is preserved
3. Click **"Commit changes"**

> **Tip:** If you have Claude Code installed, you can do this faster from your
> terminal with `git`. But drag-and-drop on the website works perfectly fine.

---

## Step 3 — Get a Gmail App Password

*(Skip if you already have one)*

1. Go to your Google Account → https://myaccount.google.com
2. Click **Security** → **2-Step Verification** (enable it if not already on)
3. Go back to Security → scroll down → **App passwords**
4. Select app: **Mail** → Generate
5. Copy the 16-character password shown (e.g. `abcd efgh ijkl mnop`)
   — remove the spaces when you use it

---

## Step 4 — Add your credentials as GitHub Secrets

This keeps your email and password secure — they're never visible in the code.

1. In your GitHub repository, click **Settings** (top menu)
2. In the left sidebar → **Secrets and variables** → **Actions**
3. Click **"New repository secret"** and add these three secrets one by one:

| Secret name       | Value                        |
|-------------------|------------------------------|
| `EMAIL_SENDER`    | your Gmail address           |
| `EMAIL_PASSWORD`  | your 16-char App Password    |
| `EMAIL_RECIPIENT` | where to send the digest     |

---

## Step 5 — Test it manually

1. In your repository, click the **Actions** tab (top menu)
2. Click **"Daily Disinformation Digest"** in the left list
3. Click **"Run workflow"** → **"Run workflow"** (green button)
4. Watch the run — it should turn green ✅ in about 30 seconds
5. Check your inbox!

---

## Step 6 — You're done! 🎉

The digest will now arrive every morning at **8:00 AM Brussels time**.

To change the time, edit `.github/workflows/daily-digest.yml`:
```yaml
- cron: '0 7 * * *'   # 07:00 UTC = 08:00 Brussels (CET)
                       # Change to '0 6 * * *' for 07:00 Brussels
```

Cron format: `minute hour day month weekday`
Use https://crontab.guru to build your schedule visually.

---

## Troubleshooting

**Run failed (red ✗):**
- Click the failed run → click the job name → read the error log
- Most common issue: wrong App Password → regenerate and update the secret

**No email received:**
- Check your spam folder
- Verify EMAIL_RECIPIENT secret is correct

**Want to pause it?**
- Go to Actions → Daily Disinformation Digest → click the "..." menu → Disable workflow

---

## Running locally (optional)

```bash
export EMAIL_SENDER="you@gmail.com"
export EMAIL_PASSWORD="your_app_password"
export EMAIL_RECIPIENT="you@gmail.com"
export RUN_MODE=local   # enables the daily scheduler
python monitor.py
```
