# 📰 Disinformation Monitor Agent

A Python agent that monitors top news and scientific articles on disinformation
and sends you a daily email digest every morning.

---

## Sources monitored

| Source | Type |
|---|---|
| Google News RSS | News |
| arXiv | Academic |
| PubMed / NCBI | Academic |
| EDMO | EU/Institutional |
| EC Digital Strategy | EU/Institutional |

---

## Setup

### 1. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure your email

Open `config.py` and fill in:

```python
"sender":    "your_email@gmail.com",
"password":  "your_app_password",   # See note below
"recipient": "you@example.com",
"send_time": "08:00"                # Time to send daily digest
```

**Gmail App Password** (required — do not use your main password):
1. Enable 2FA on your Google account
2. Visit https://myaccount.google.com/apppasswords
3. Generate a password for "Mail" and paste it in config.py

### 3. Run the agent

```bash
python monitor.py
```

The agent will:
- Run immediately on startup (sends a first digest)
- Then run every day at the time you configured
- Keep running in the background (use `screen`, `tmux`, or a system service to keep it alive)

---

## Running in the background (Linux/Mac)

Using `nohup`:
```bash
nohup python monitor.py > monitor.log 2>&1 &
```

Using `screen`:
```bash
screen -S monitor
python monitor.py
# Ctrl+A then D to detach
```

---

## Customising keywords

In `monitor.py`, edit the `KEYWORDS` list near the top:

```python
KEYWORDS = [
    "disinformation", "misinformation", "information integrity",
    ...
]
```

---

## Project structure

```
disinformation-monitor/
├── monitor.py        # Main agent
├── config.py         # Your settings (email, schedule)
├── requirements.txt  # Python dependencies
└── README.md
```
