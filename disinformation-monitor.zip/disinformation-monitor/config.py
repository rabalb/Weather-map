"""
Configuration for Disinformation Monitor Agent

When running on GitHub Actions, credentials are read from environment variables.
When running locally, you can either set environment variables or fill in the
values directly below.
"""

import os

CONFIG = {
    # ── Schedule ──────────────────────────────────────────────
    # Only used when running locally (GitHub Actions uses cron instead)
    "send_time": "08:00",

    # ── Email Settings ────────────────────────────────────────
    "email": {
        # Reads from GitHub Secrets (or local environment variables)
        # To run locally: set these env vars, or replace os.getenv(...) with your values
        "sender":    os.getenv("EMAIL_SENDER",    "your_email@gmail.com"),
        "password":  os.getenv("EMAIL_PASSWORD",  "your_app_password_here"),
        "recipient": os.getenv("EMAIL_RECIPIENT", "recipient@example.com"),

        # Gmail SMTP (change if using Outlook, etc.)
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 465,
    }
}

# ── Local usage ───────────────────────────────────────────────────────────────
#
# Option A — set environment variables in your terminal before running:
#   export EMAIL_SENDER="you@gmail.com"
#   export EMAIL_PASSWORD="your_app_password"
#   export EMAIL_RECIPIENT="you@gmail.com"
#   python monitor.py
#
# Option B — replace os.getenv(...) above with your actual values directly.
#   (Do NOT commit real passwords to GitHub if you do this!)
#
# GMAIL APP PASSWORD:
#   1. Enable 2FA on your Google account
#   2. Go to https://myaccount.google.com/apppasswords
#   3. Generate a password for "Mail" and use it as EMAIL_PASSWORD
#
# ─────────────────────────────────────────────────────────────────────────────
