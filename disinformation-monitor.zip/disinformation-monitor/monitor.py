"""
Disinformation Monitor Agent
Fetches top articles daily from multiple sources and sends an email digest.
"""

import feedparser
import requests
import smtplib
import schedule
import time
import logging
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from bs4 import BeautifulSoup
from config import CONFIG

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# SEARCH KEYWORDS
# ─────────────────────────────────────────────
KEYWORDS = [
    "disinformation", "misinformation", "information integrity",
    "fake news", "influence operations", "information manipulation",
    "media literacy", "fact-checking", "computational propaganda"
]

QUERY = " OR ".join(f'"{k}"' for k in KEYWORDS)

# ─────────────────────────────────────────────
# SOURCE FETCHERS
# ─────────────────────────────────────────────

def fetch_google_news():
    """Fetch from Google News RSS."""
    results = []
    url = f"https://news.google.com/rss/search?q={requests.utils.quote(QUERY)}&hl=en-US&gl=US&ceid=US:en"
    feed = feedparser.parse(url)
    for entry in feed.entries[:10]:
        results.append({
            "title": entry.get("title", ""),
            "url": entry.get("link", ""),
            "source": entry.get("source", {}).get("title", "Google News"),
            "date": entry.get("published", ""),
            "summary": BeautifulSoup(entry.get("summary", ""), "html.parser").get_text()[:200],
            "category": "News"
        })
    log.info(f"Google News: {len(results)} articles fetched")
    return results


def fetch_arxiv():
    """Fetch from arXiv API."""
    results = []
    query = "disinformation OR misinformation OR information+integrity"
    url = (
        f"http://export.arxiv.org/api/query?search_query=all:{query}"
        f"&start=0&max_results=10&sortBy=submittedDate&sortOrder=descending"
    )
    response = requests.get(url, timeout=10)
    feed = feedparser.parse(response.text)
    for entry in feed.entries:
        results.append({
            "title": entry.get("title", "").replace("\n", " "),
            "url": entry.get("link", ""),
            "source": "arXiv",
            "date": entry.get("published", ""),
            "summary": entry.get("summary", "")[:200],
            "category": "Academic"
        })
    log.info(f"arXiv: {len(results)} articles fetched")
    return results


def fetch_pubmed():
    """Fetch from PubMed via NCBI E-utilities."""
    results = []
    search_url = (
        "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
        f"?db=pubmed&term=disinformation+OR+misinformation&retmax=10&sort=date&retmode=json"
    )
    r = requests.get(search_url, timeout=10)
    ids = r.json().get("esearchresult", {}).get("idlist", [])
    if ids:
        fetch_url = (
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
            f"?db=pubmed&id={','.join(ids)}&retmode=json"
        )
        r2 = requests.get(fetch_url, timeout=10)
        docs = r2.json().get("result", {})
        for uid in ids:
            doc = docs.get(uid, {})
            if not doc:
                continue
            results.append({
                "title": doc.get("title", ""),
                "url": f"https://pubmed.ncbi.nlm.nih.gov/{uid}/",
                "source": "PubMed",
                "date": doc.get("pubdate", ""),
                "summary": f"Authors: {doc.get('authors', [{}])[0].get('name', 'N/A') if doc.get('authors') else 'N/A'}",
                "category": "Academic"
            })
    log.info(f"PubMed: {len(results)} articles fetched")
    return results


def fetch_eu_sources():
    """Fetch from EU/EDMO RSS feeds."""
    feeds = [
        ("EDMO", "https://edmo.eu/feed/"),
        ("EC Digital", "https://digital-strategy.ec.europa.eu/en/rss.xml"),
        ("EUR-Lex Disinformation", "https://eur-lex.europa.eu/search.html?SUBDOM_INIT=ALL_ALL&DTS_DOM=ALL&type=advanced&lang=en&andText0=disinformation&RSS=true"),
    ]
    results = []
    for name, url in feeds:
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:4]:
                title = entry.get("title", "")
                summary = BeautifulSoup(entry.get("summary", ""), "html.parser").get_text()[:200]
                # Filter to relevant entries only
                combined = (title + summary).lower()
                if any(k in combined for k in ["disinformation", "misinformation", "information integrity", "fake"]):
                    results.append({
                        "title": title,
                        "url": entry.get("link", ""),
                        "source": name,
                        "date": entry.get("published", ""),
                        "summary": summary,
                        "category": "EU/Institutional"
                    })
        except Exception as e:
            log.warning(f"Could not fetch {name}: {e}")
    log.info(f"EU Sources: {len(results)} articles fetched")
    return results


# ─────────────────────────────────────────────
# DEDUPLICATION & RANKING
# ─────────────────────────────────────────────

def deduplicate(articles):
    seen = set()
    unique = []
    for a in articles:
        key = a["title"].lower()[:60]
        if key not in seen:
            seen.add(key)
            unique.append(a)
    return unique


def rank_articles(articles, top_n=10):
    """Simple relevance ranking based on keyword density."""
    def score(a):
        text = (a["title"] + " " + a["summary"]).lower()
        return sum(text.count(k.lower()) for k in KEYWORDS)
    return sorted(articles, key=score, reverse=True)[:top_n]


# ─────────────────────────────────────────────
# EMAIL DIGEST
# ─────────────────────────────────────────────

def build_html_email(articles):
    date_str = datetime.now().strftime("%A, %d %B %Y")
    category_colors = {
        "News": "#1a73e8",
        "Academic": "#0f9d58",
        "EU/Institutional": "#e37400"
    }

    rows = ""
    for i, a in enumerate(articles, 1):
        color = category_colors.get(a["category"], "#555")
        rows += f"""
        <tr>
          <td style="padding: 16px; border-bottom: 1px solid #eee; vertical-align:top; width:30px; color:#999; font-size:18px; font-weight:bold;">{i}</td>
          <td style="padding: 16px; border-bottom: 1px solid #eee;">
            <span style="background:{color}; color:white; font-size:11px; padding:2px 8px; border-radius:12px; font-family:sans-serif;">{a['category']}</span>
            &nbsp;<span style="color:#999; font-size:12px;">{a['source']}</span>
            <br><br>
            <a href="{a['url']}" style="font-size:16px; font-weight:600; color:#1a1a1a; text-decoration:none;">{a['title']}</a>
            <p style="color:#555; font-size:13px; margin:8px 0 0 0;">{a['summary']}…</p>
          </td>
        </tr>"""

    html = f"""
    <html><body style="margin:0; padding:0; background:#f5f5f5; font-family: Georgia, serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5; padding: 30px 0;">
      <tr><td align="center">
        <table width="680" cellpadding="0" cellspacing="0" style="background:white; border-radius:8px; overflow:hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">

          <!-- Header -->
          <tr><td style="background:#1a1a2e; padding: 32px 40px;">
            <p style="margin:0; color:#aab4d4; font-size:12px; letter-spacing:2px; text-transform:uppercase;">Daily Intelligence Digest</p>
            <h1 style="margin:8px 0 0 0; color:white; font-size:26px;">Disinformation Monitor</h1>
            <p style="margin:6px 0 0 0; color:#aab4d4; font-size:14px;">{date_str}</p>
          </td></tr>

          <!-- Intro -->
          <tr><td style="padding: 24px 40px 8px 40px; color:#555; font-size:14px; border-bottom: 2px solid #eee;">
            Top {len(articles)} articles on disinformation and information integrity, curated from news, academic, and EU institutional sources.
          </td></tr>

          <!-- Articles -->
          <tr><td>
            <table width="100%" cellpadding="0" cellspacing="0" style="padding: 0 24px;">
              {rows}
            </table>
          </td></tr>

          <!-- Footer -->
          <tr><td style="background:#f9f9f9; padding: 20px 40px; text-align:center; color:#aaa; font-size:12px; border-top: 1px solid #eee;">
            Disinformation Monitor · Automated Daily Digest · {date_str}
          </td></tr>

        </table>
      </td></tr>
    </table>
    </body></html>"""
    return html


def send_email(articles):
    cfg = CONFIG["email"]
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"📰 Disinformation Monitor — {datetime.now().strftime('%d %b %Y')}"
    msg["From"] = cfg["sender"]
    msg["To"] = cfg["recipient"]

    html = build_html_email(articles)
    msg.attach(MIMEText(html, "html"))

    with smtplib.SMTP_SSL(cfg["smtp_host"], cfg["smtp_port"]) as server:
        server.login(cfg["sender"], cfg["password"])
        server.sendmail(cfg["sender"], cfg["recipient"], msg.as_string())
    log.info(f"Email digest sent to {cfg['recipient']}")


# ─────────────────────────────────────────────
# MAIN JOB
# ─────────────────────────────────────────────

def run_monitor():
    log.info("=== Starting Disinformation Monitor ===")
    all_articles = []
    for fetcher in [fetch_google_news, fetch_arxiv, fetch_pubmed, fetch_eu_sources]:
        try:
            all_articles.extend(fetcher())
        except Exception as e:
            log.error(f"Fetcher {fetcher.__name__} failed: {e}")

    articles = rank_articles(deduplicate(all_articles), top_n=10)
    log.info(f"Top {len(articles)} articles selected after deduplication and ranking")

    if articles:
        send_email(articles)
    else:
        log.warning("No articles found — email not sent.")


# ─────────────────────────────────────────────
# SCHEDULER
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import os
    # On GitHub Actions: run once and exit.
    # Locally with RUN_MODE=local: run on a daily schedule.
    if os.getenv("RUN_MODE") == "local":
        send_time = CONFIG.get("send_time", "08:00")
        log.info(f"Local mode: scheduled daily at {send_time}. Running first check now...")
        run_monitor()
        schedule.every().day.at(send_time).do(run_monitor)
        while True:
            schedule.run_pending()
            time.sleep(60)
    else:
        log.info("Running single digest (GitHub Actions mode)...")
        run_monitor()
